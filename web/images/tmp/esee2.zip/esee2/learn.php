<?php


require './lib.php';

$str = "#......#
##....##
##....##
##....##
##....##
##....##
##....##
##....##
.#######
..######
......##
......##
......##
......##
......##";

$title = 'Ч';

$w = 8;

$h = 15;

$weights = [];

for($i = 0; $i < strlen($str); $i++) {
        $c = substr($str, $i, 1);
        if($c != '.' && $c != '#') {
                continue;
        }
        $weights[] = $c == '#' ? 1 : 0;
}

$lib = LibChars::getInstance();

$node = $lib->findByTitle($title, $w, $h);
if(is_null($node)) {
        $node = new Node();
        $node->title = $title;
        $node->weights = $weights;
	$node->learn = 1;
	$node->width = $w;
	$node->height = $h;
} else {
       $node = Node::updateWeight($weights, $node);
}


$lib->saveNode($node);

 
